<div class="bg-white dark:bg-dark w-full flex-none lg:z-20 border-b border-ddd dark:border-dark">
    <div class="max-w-8xl mx-auto">
        <div class="border-b border-slate-900/10 lg:px-8 lg:border-0 dark:border-slate-300/10 mx-4 lg:mx-0">
            <div class="relative flex items-center">
                <a href=""
                    class="py-3 px-4 mr-4 border-b-2 border-white dark:border-dark dark:hover:border-white hover:border-dark-1 hover:font-semibold">TOP</a>
                <a href=""
                    class="py-3 px-4 mr-4 border-b-2 border-white dark:border-dark dark:hover:border-primary hover:border-primary hover:font-semibold">少年・青年</a>
                <a href=""
                    class="py-3 px-4 mr-4 border-b-2 border-white dark:border-dark dark:hover:border-orange hover:border-orange hover:font-semibold">少女・女性</a>
                <a href=""
                    class="py-3 px-4 mr-4 border-b-2 border-white dark:border-dark dark:hover:border-yellow hover:border-yellow hover:font-semibold">TL</a>
                <a href=""
                    class="py-3 px-4 mr-4 border-b-2 border-white dark:border-dark dark:hover:border-purple hover:border-purple hover:font-semibold">BL</a>
                <a href=""
                    class="py-3 px-4 mr-4 border-b-2 border-white dark:border-dark dark:hover:border-pink hover:border-pink hover:font-semibold">オトナ</a>
            </div>
        </div>
    </div>
</div>
