<div class="w-full h-[550px] bg-eee dark:bg-dark-1 flex items-center justify-center text-2xl">
    フッター
</div>
