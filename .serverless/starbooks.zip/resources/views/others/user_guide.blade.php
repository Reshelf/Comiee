@extends('app')

@section('title', 'ご利用ガイド - Starbooks')

@section('content')
    @include('_patials._nav')

    <div class="container my-8">
        <h2 class="text-3xl font-semibold">ご利用ガイド</h2>
    </div>

    @include('_patials._footer')
@endsection
