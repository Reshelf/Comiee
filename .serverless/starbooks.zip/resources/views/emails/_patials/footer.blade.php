<tr>
    <td style="padding:30px;background:#fff;">
        <table role="presentation"
            style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Noto Sans JP;">
            <tr>
                <td style="padding:0;width:50%;" align="left">
                    <p style="margin:0;font-size:14px;line-height:16px;font-family:Noto Sans JP;">
                        &reg; Starbooks {{ \Carbon\Carbon::now()->format('Y') }}<br />
                    </p>
                </td>
                <td style="padding:0;width:50%;" align="right">
                    <table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
                        <tr>
                            <td style="padding:0 0 0 10px;width:38px;">
                                <a href="http://www.twitter.com/" style=""><img
                                        src="https://assets.codepen.io/210284/tw_1.png" alt="Twitter" width="38"
                                        style="height:auto;display:block;border:0;" /></a>
                            </td>
                            <td style="padding:0 0 0 10px;width:38px;">
                                <a href="http://www.facebook.com/" style=""><img
                                        src="https://assets.codepen.io/210284/fb_1.png" alt="Facebook" width="38"
                                        style="height:auto;display:block;border:0;" /></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </td>
</tr>
